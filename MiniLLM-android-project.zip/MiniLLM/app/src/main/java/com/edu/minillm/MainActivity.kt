package com.edu.minillm

import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.io.File

class MainActivity : Activity() {
    private lateinit var web: WebView
    private val engine: LlmEngine = StubEngine()
    private var ramLimitMb = 3072

    private val dataDir get() = File(filesDir, "training_data").apply { mkdirs() }   // persistent
    private val cacheData get() = File(cacheDir, "training_cache").apply { mkdirs() } // disposable

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    inner class Bridge {
        @JavascriptInterface fun info(): String {
            val mi = ActivityManager.MemoryInfo()
            (getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
            return JSONObject().put("totalMb", mi.totalMem / 1048576).put("availMb", mi.availMem / 1048576)
                .put("params", ModelSpec.PARAMS).put("layers", ModelSpec.LAYERS)
                .put("dim", ModelSpec.D_MODEL).put("seq", ModelSpec.MAX_SEQ)
                .put("limit", ramLimitMb).put("dataKb", dataDir.walk().sumOf { it.length() } / 1024)
                .put("loaded", engine.loaded).toString()
        }
        @JavascriptInterface fun setLimit(mb: Int) { ramLimitMb = mb }
        @JavascriptInterface fun pickData() = runOnUiThread {
            startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("text/*"), 1)
        }
        @JavascriptInterface fun clearCache() { cacheData.deleteRecursively(); js("refresh()") }
        @JavascriptInterface fun ask(prompt: String) {
            Thread { val r = engine.generate(prompt, ramLimitMb); js("onReply(${JSONObject.quote(r)})") }.start()
        }
    }

    @Deprecated("kept dependency-free")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri = data?.data ?: return
        if (req != 1 || res != RESULT_OK) return
        val name = "data_${System.currentTimeMillis()}.txt"
        contentResolver.openInputStream(uri)?.use { i ->
            File(dataDir, name).outputStream().use { o -> i.copyTo(o) }   // app storage
        }
        File(dataDir, name).copyTo(File(cacheData, name), overwrite = true) // cache copy
        js("refresh()")
    }
}
