package com.edu.minillm

/** Model hyper-parameters (match the PyTorch config). */
object ModelSpec {
    const val VOCAB = 32_000; const val D_MODEL = 2048; const val LAYERS = 16
    const val HEADS = 16; const val MAX_SEQ = 256; const val FFN = 7168
    // attention 4*d^2 + SwiGLU 3*d*ffn per layer, plus embeddings and untied head
    val PARAMS: Long = LAYERS * (4L * D_MODEL * D_MODEL + 3L * D_MODEL * FFN) + 2L * VOCAB * D_MODEL
}

/** Swap StubEngine for a real runtime (ONNX Runtime, llama.cpp JNI...) later. */
interface LlmEngine {
    val loaded: Boolean
    fun generate(prompt: String, ramLimitMb: Int): String
}

class StubEngine : LlmEngine {
    override val loaded = false
    override fun generate(prompt: String, ramLimitMb: Int) =
        "No weights loaded yet. Your prompt had ${prompt.length} characters; " +
        "RAM cap is $ramLimitMb MB. Plug a quantized model into LlmEngine to get real replies."
}
